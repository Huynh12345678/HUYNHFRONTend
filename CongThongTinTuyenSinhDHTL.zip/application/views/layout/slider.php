<div id="slider">
    <div class="carousel owl-carousel owl-theme">
        <a href="" class="image-item">
            <img src="<?php echo base_url();?>asset/image/banner/1.jpg" alt="">
        </a href="">
        <a href="" class="image-item">
            <img src="<?php echo base_url();?>asset/image/banner/1.jpg" alt="">
        </a href="">
        <a href="" class="image-item">
            <img src="<?php echo base_url();?>asset/image/banner/1.jpg" alt="">
        </a href="">
        <a href="" class="image-item">
            <img src="<?php echo base_url();?>asset/image/banner/1.jpg" alt="">
        </a href="">
    </div>
</div>